
#guitemperatureconverter.py
#Purpose: To convert a temperaturte in fahrenheit to the temperature in Celcius  

import easygui #imports easyguit module to make gui 
temp = easygui.integerbox("What is the temperature in Fahrenheit?") #asks user what the temperature in fahrenheit is  
c = 5.0/9.0*(temp - 32.0) #finds tempreatur in celcius 
c=str(c)#converts numbre to string 
easygui.msgbox("The temperature in Celcius is " +c) #outputs the temperature in Celcius 
